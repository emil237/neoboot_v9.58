# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/__init__.py
pass